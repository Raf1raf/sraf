project_folder/
├── bot.py
├── languages/
│   ├── ar.py
│   └── en.py
├── main.py
└── README.md