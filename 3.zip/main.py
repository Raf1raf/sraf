import telebot
from telebot import types
import bot  


bot_token = '6655386646:AAFb_6CAhLW0s7948kEW8Y3LksU6tS2z_9k'
bot_instance = telebot.TeleBot(bot_token)

@bot_instance.message_handler(commands=['start'])
def handle_start(message):
    markup = types.ReplyKeyboardMarkup()
    item_arabic = types.KeyboardButton("العربية")
    item_english = types.KeyboardButton("English")
    markup.add(item_arabic, item_english)
    bot_instance.send_message(message.chat.id, "اهلا بك. اختر اللغة:", reply_markup=markup)

@bot_instance.message_handler(func=lambda message: message.text == "العربية")
def handle_arabic(message):
    bot.set_language('ar')  
    bot.execute_commands()  # تنفيذ الأوامر من ar.py

@bot_instance.message_handler(func=lambda message: message.text == "English")
def handle_english(message):
    bot.set_language('en')  
    bot.execute_commands()  # تنفيذ الأوامر من en.py

bot_instance.polling()