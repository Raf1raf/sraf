language = 'en'  # اللغة الافتراضية Default language 

def set_language(lang):
    global language
    language = lang
###################
def execute_commands():
    if language == 'en':
        # قائمة الأوامر 
        pass  # add here en
        
        
        
        
  ##################
  
    elif language == 'ar':
    
        # add here ar
        pass  # اضف الأوامر الخاصة بالعربية هنا
        
        ##############