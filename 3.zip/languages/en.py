# en.py
def en_command():
    pass  # add here en اضف هنا العربيه