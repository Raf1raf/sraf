# ar.py
def ar_command():
    pass  #add here ar اضف هنا العربيه